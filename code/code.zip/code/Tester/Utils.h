#define STATUS int

typedef char BOOL;